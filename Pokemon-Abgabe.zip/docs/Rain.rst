Rain module
===========

.. automodule:: Rain
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
