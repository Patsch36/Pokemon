tile module
===========

.. automodule:: tile
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
