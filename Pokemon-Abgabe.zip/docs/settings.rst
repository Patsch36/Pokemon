settings module
===============

.. automodule:: settings
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
