<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Standard-Tileset" tilewidth="32" tileheight="32" tilecount="1610" columns="46">
 <image source="../../graphics/Standard-Tileset.png" width="1472" height="1120"/>
</tileset>
