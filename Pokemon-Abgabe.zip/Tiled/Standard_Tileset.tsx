<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Standard" tilewidth="16" tileheight="16" tilecount="1610" columns="46">
 <grid orientation="orthogonal" width="32" height="32"/>
 <image source="../graphics/Custom_Natur_Public.png" width="736" height="560"/>
</tileset>
