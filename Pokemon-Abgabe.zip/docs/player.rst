player module
=============

.. automodule:: player
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
