# Pokemon
Pygames Implementierg eines Open Wolrd 2D games mit automatischr Map- Generierung und Datenverwaltung/ Bearbeitung

## Documentation
The documentation is found [here](docs%5C_build%5Chtml%5Cindex.html) or under docs/_build/html/index.html.