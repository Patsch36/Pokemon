language module
===============

.. automodule:: language
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
