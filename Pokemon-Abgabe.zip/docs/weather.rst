weather module
==============

.. automodule:: weather
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
