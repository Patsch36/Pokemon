.. Game Engine documentation master file, created by
   sphinx-quickstart on Sat May 28 14:53:50 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Game Engine's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro
   todos
   modules
   tests



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
