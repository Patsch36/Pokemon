NPC\_data module
================

.. automodule:: NPC_data
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
