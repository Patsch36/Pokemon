npc module
==========

.. automodule:: npc
   :members:
   :undoc-members:
   :private-members:
   :show-inheritance:
