ToDos
=====

- :meth:`weather.Weather.__weather_mappe`
    Add all possible weather codes


- :meth:`NPC`
    Find bug why some NPC cant talk