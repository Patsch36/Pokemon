debug module
============

.. automodule:: debug
   :members:
   :private-members:
   :undoc-members:
   :show-inheritance:
